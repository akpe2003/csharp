﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Collections.Concurrent;
using System.Text;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
namespace InventoryManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("My Inventory Managment System.");
            Console.WriteLine();
            int Response1;
            List<string> Products = new List<string>();
            List<double> Price = new List<double>();
            List<int> Quantity = new List<int>();
            Console.WriteLine("1:Add Products.");
            Console.WriteLine("2:Remove Product.");
            Console.WriteLine("3:Display Products.");
            Console.WriteLine("4:Restock Products.");
            Console.WriteLine("5:Exit");
            Console.WriteLine();
            Console.Write("From the menu above, What will you like to do? Enter a number from 1 to 5.");
            Response1 = Convert.ToInt32(Console.ReadLine());
            string respond = "";
            Console.WriteLine();
            Console.WriteLine("Are you ready to begin entering in the product details?Yes/No.");
            respond = Console.ReadLine().ToLower().Trim();
            while(respond =="yes")
            {
                if (Response1 == 1)
                {

                    Console.Write("What's the name of the product?");
                    string Response2 = Console.ReadLine();
                    Products.Add(Response2);
                    Console.WriteLine();
                    Console.Write("What's the cost of the product?");
                    double price = Convert.ToDouble(Console.ReadLine());
                    Price.Add(price);
                    Console.WriteLine();
                    Console.Write("What's the quantity of this product you are adding to the shop?");
                    int quantity = Convert.ToInt32(Console.ReadLine());
                    Quantity.Add(quantity);
                    Console.WriteLine();
                    Console.WriteLine("Do you still want to enter product details?Yes/No.");
                    string Answer_Me = Console.ReadLine();
                    if (Answer_Me == "yes")
                    {
                        continue;
                    }
                    /*else if (Answer_Me == "no")
                    {
                        break;
                    }*/
                    Console.WriteLine();
                    Console.WriteLine("1:Add Products.");
                    Console.WriteLine("2:Remove Product.");
                    Console.WriteLine("3:Display Products.");
                    Console.WriteLine("4:Restock Products.");
                    Console.WriteLine("5:Exit");
                    Console.Write("What do you want to do next?Please use the menu above by responding with numbers from 1 to 5.");
                    Response1 = Convert.ToInt32(Console.ReadLine());
                    if (Response1 == 2)
                    {
                        Console.WriteLine();
                        Console.Write("What product do you want to remove?");
                        string removedProduct = Console.ReadLine().ToLower().Trim();
                        for (int index = 0; index < Products.Count; index++)
                        {
                            if (Products[index] == removedProduct)
                            {
                                int current = index;
                                Products.RemoveAt(current);
                                Price.RemoveAt(current);
                                Quantity.RemoveAt(current);
                            }
                        }
                        Console.WriteLine();
                        Console.WriteLine("Product Successfully Removed!!!");
                    }
                    else if (Response1 == 3)
                    {
                        for(int i=0;i<Products.Count;i++)
                        {
                            
                          Console.WriteLine($"{Products[i]} : {Quantity[i]}");
                            
                        }
                    }
                    else if (Response1 == 4)
                    {
                        Console.Write("What product do you want to restock?");
                        string product_restocked = Console.ReadLine().ToLower().Trim();
                        Console.WriteLine();
                        Console.Write("By how much do you want to restock this particular product?");
                        int num_restock = Convert.ToInt32(Console.ReadLine());
                        for (int position = 0; position < Products.Count; position++)
                        {
                            if (Products[position] == product_restocked)
                            {
                                int new_position = position;
                                Quantity[new_position] += num_restock;
                            }
                        }
                        Console.WriteLine($"Product is succcessfully restocked.");
                    }
                    else if (Response1 == 5)
                    {
                        Console.WriteLine("GoodBye!!!");
                    }
                }
                Console.WriteLine("Do you still want to do something with the system?");
                respond = Console.ReadLine().ToLower().Trim();
                if (respond == "yes") 
                {
                    Console.WriteLine("1:Add Products.");
                    Console.WriteLine("2:Remove Product.");
                    Console.WriteLine("3:Display Products.");
                    Console.WriteLine("4:Restock Products.");
                    Console.WriteLine("5:Exit");
                    Console.Write("What do you want to do next?Please use the menu above by responding with numbers from 1 to 5.");
                    Response1 = Convert.ToInt32(Console.ReadLine());

                }
                else if(respond == "no")
                {
                    break;
                }
            }
            Console.WriteLine();
            Console.WriteLine("Press any key to close.");
            Console.ReadKey();
        }
    }
}
