﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Collections.Concurrent;
using System.Linq;
namespace StudentGradeManagementSystem
{
    class Program
    {
        public static void Main(string[] args)
        {
            List<string> Student_Name = new List<string>();
            List<int> ID = new List<int>();
            List<double> Math_Score = new List<double>();
            List<double> English_Score = new List<double>();
            List<double> Physics_Score = new List<double>();
            List<double> Chemistry_Score = new List<double>();
            List<double> Biology_Score = new List<double>();
            List<double> Economics_Score = new List<double>();
            List<double> Geography_Score = new List<double>();
            List<double> Agric_Score = new List<double>();
            List<double> FurtherMath_Score = new List<double>();
            Console.WriteLine("My Student Grade Management System!!!");
            Console.WriteLine();
            Console.Write("Are you ready to begin entering student records into the system?Yes/No.");
            string first_Answer = Console.ReadLine().ToLower().Trim();
            Console.WriteLine();
            do
            {
                
                
                Console.Write("What's this student's fullname?");
                string fullName = Console.ReadLine().ToLower().Trim();
                Student_Name.Add(fullName);
                Console.WriteLine();
                Console.Write("What's this student's Identity Number?");
                int Id_Number = Convert.ToInt32(Console.ReadLine());
                ID.Add(Id_Number);
                Console.WriteLine();
                Console.Write("What's this student's Mathematics score?");
                double math = Convert.ToDouble(Console.ReadLine());
                Math_Score.Add(math);
                Console.WriteLine();
                Console.Write("What's this student's English Language score?");
                double english = Convert.ToDouble(Console.ReadLine());
                English_Score.Add(english);
                Console.WriteLine();
                Console.Write("What's this student's Physics Score?");
                double physics = Convert.ToDouble(Console.ReadLine());
                Physics_Score.Add(physics);
                Console.WriteLine();
                Console.Write("What's this student's Chemistry score?");
                double chemistry = Convert.ToDouble(Console.ReadLine());
                Chemistry_Score.Add(chemistry);
                Console.WriteLine();
                Console.Write("What's this student's Biology score?");
                double biology = Convert.ToDouble(Console.ReadLine());
                Biology_Score.Add(biology);
                Console.WriteLine();
                Console.Write("What's this student's Economics score?");
                double economics = Convert.ToDouble(Console.ReadLine());
                Economics_Score.Add(economics);
                Console.WriteLine();
                Console.Write("What's this student's Geography score?");
                double geography = Convert.ToDouble(Console.ReadLine());
                Geography_Score.Add(geography);
                Console.WriteLine();
                Console.Write("What's this student's Agricultural Science score?");
                double agric = Convert.ToDouble(Console.ReadLine());
                Agric_Score.Add(agric);
                Console.WriteLine();
                Console.Write("What's this student's Further Mathematics score?");
                double furthermath = Convert.ToDouble(Console.ReadLine());
                FurtherMath_Score.Add(furthermath);
                Console.WriteLine();
                Console.Write("Do you still want to enter student details?Yes/No.");
                first_Answer = Console.ReadLine().ToLower().Trim();
                Console.WriteLine();
                if (first_Answer == "yes")
                {
                    continue;
                }
                else if (first_Answer == "no")
                {
                    Console.WriteLine("1.Average grade for each student.");
                    Console.WriteLine("2.Display student records.");
                    Console.Write("What do you want to do next?Respond with either number 1 or 2 from the menu above.");
                    int next_decision = Convert.ToInt32(Console.ReadLine());
                    if (next_decision == 1)
                    {
                        Console.WriteLine("What is the fullname of the student to calculate the average score?");
                        string stud_name = Console.ReadLine().ToLower().Trim();
                        int current_number = 0;
                        for(int index=0;index<Student_Name.Count;index++)
                        {
                            if (Student_Name[index].ToLower().Trim() == stud_name)
                            {
                                current_number = index;
                                
                                double total_score = Math_Score[current_number] + English_Score[current_number] + Physics_Score[current_number] + Chemistry_Score[current_number] + Biology_Score[current_number] + Economics_Score[current_number] + Geography_Score[current_number] + Agric_Score[current_number] + FurtherMath_Score[current_number];
                                double average = (double)(total_score / 9);
                                Console.WriteLine($"The student whose name is: {stud_name} has an average score of {average}.");
                            }
                        }
                        
                    }
                    else if (next_decision == 2)
                    {
                        Console.Write("What's the full name of the student whose academic recore you want to view?");
                        string record_name = Console.ReadLine().ToLower().Trim();
                        for (int i = 0; i < Student_Name.Count; i++)
                        {
                            if (Student_Name[i].ToLower().Trim() == record_name)
                            {
                                int presentNumber = i;
                                Console.WriteLine("FullName\tMathematics\tEnglish\tPhysics\tChemistry\tBiology\tEconomics\tGeography\tAgric Scienc\tFurther Mathematics.");
                                Console.Write($"{record_name}\t\t{Math_Score[presentNumber]}\t\t{English_Score[presentNumber]}\t\t{Physics_Score[presentNumber]}\t\t{Chemistry_Score[presentNumber]}\t\t{Biology_Score[presentNumber]}\t\t{Economics_Score[presentNumber]}\t\t{Geography_Score[presentNumber]}\t\t{Agric_Score[presentNumber]}\t\t{FurtherMath_Score[presentNumber]}");
                                Console.WriteLine();
                            }
                        }
                    }
                }
                Console.WriteLine();
                Console.Write("Do you still want to enter student details?Yes/No.");
                first_Answer = Console.ReadLine().ToLower().Trim();
                if (first_Answer == "yes") 
                {
                    continue;
                }
                else
                {
                    break;
                }
            } while (first_Answer == "yes");
            Console.WriteLine();
            Console.WriteLine("Press any key to continue...");
            Console.WriteLine();
            ConsoleKeyInfo keyInfo = Console.ReadKey();  // waits for a key press
            Console.WriteLine($"\nYou pressed: {keyInfo.Key}");
        }
    }
}
